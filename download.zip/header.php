<div id="links">
    <a href="index.php">Главная</a>
    <a href="films.php">Фильмы</a>
    <a href="seans.php">Сеансы</a>
    <a href="registration.php">Регистрация</a>
    <a href="authorisation.php">Авторизация</a>
    </div>