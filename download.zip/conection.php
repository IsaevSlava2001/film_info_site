<?php
$user="id11999011_user";
$host="localhost";
$database="id11999011_film_info";
$password="Dl0DI!IW<1rm=E%L";
?>